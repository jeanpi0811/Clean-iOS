export const colors = {
  background: '#0B0E14',
  surface: 'rgba(255,255,255,0.06)',
  surfaceBorder: 'rgba(255,255,255,0.12)',
  primary: '#5B8CFF',
  primaryGradientEnd: '#7C5BFF',
  success: '#34D399',
  warning: '#FBBF24',
  danger: '#F87171',
  textPrimary: '#F5F7FA',
  textSecondary: '#9AA4B2',
};
